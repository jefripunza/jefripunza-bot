### GITHUB
#### stater
```bash
git init && git remote add origin https://github.com/jefripunza/jefripunza-bot
```
#### push
```bash
git add . && git branch -M main  && git commit -m "bismillah" && git push -f origin main
```

### HEROKU
```bash
git add . && git commit -am "make it better" && git push heroku HEAD:main
```

### ALL PUSH
```bash
git add . && git branch -M main  && git commit -m "bismillah" && git push -f origin main && git push heroku HEAD:master
```